package controller;

import java.util.ArrayList;
/**
 *Name: Mary Mashemererwa MM 
 * Student No: 202139042
 */

import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;

import javax.faces.bean.SessionScoped;


import model.CustomerTransactions;
import service.CustomerTransactionsEJB;


@ManagedBean(name = "TransactionController")
@SessionScoped
public class TransactionController{
 
    @EJB
    private CustomerTransactionsEJB  customerTransactionsEJB;
    
  //from form
  	@ManagedProperty(value="#{customerTransactions}")
    private  CustomerTransactions customerTransactions;
  	
    private List< CustomerTransactions> customerTransactionsList = new ArrayList<>();
 
   public List< CustomerTransactions> getCustomerTranscationsList() {
       //employeeList = employeeEJB.findEmployees();
        return customerTransactionsList;
    }
 
   public String viewCustomerTransactions(){
        return "customerTransactionsList.xhtml";
    }
   
    public String addNewTransaction() {
    	customerTransactionsEJB.addNew(customerTransactions.getEntity());
      //  employeeList = employeeEJB.findEmployees();
        return "customerTransactionsList.xhtml";
    }

	public CustomerTransactions getCustomerTransactions() {
		return customerTransactions;
	}

	public void setCustomerTransactions(CustomerTransactions customerTransactions) {
		this.customerTransactions = customerTransactions;
	}
    
    
}