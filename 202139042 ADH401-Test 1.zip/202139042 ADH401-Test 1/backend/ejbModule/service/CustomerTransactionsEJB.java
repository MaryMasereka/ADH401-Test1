package service;
/**
 *Name: Mary Mashemererwa MM 
 * Student No: 202139042
 */

import javax.ejb.LocalBean;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import entities.CustomerTransactionsEntity;

/**
 
 */
@Stateless
@LocalBean
public class CustomerTransactionsEJB {


	@PersistenceContext
	private EntityManager em;
	
    public CustomerTransactionsEJB() {
        // TODO Auto-generated constructor stub
    }
    
    public void addNew(CustomerTransactionsEntity customerTransactionsEntity)
    {
    	System.out.println("============================");
    	System.out.println(customerTransactionsEntity.getName());
    	em.persist(customerTransactionsEntity);
    	System.out.println("============================");
    }

}
